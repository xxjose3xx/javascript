// Declaración de variables globales
var paginaActual = "principal";
var xslPath = "xsl/";
var xmlPath = "xml/";
var xml = xmlPath + "ies.xml";
var xhttp;

// Esta función recupera el archivo pasado como parámetro mediante una petición GET al servidor.
function loadXMLDoc(filename) {

    if(window.ActiveXObject) xhttp = new ActiveXObject("Msxml2.XMLHTTP");
    else xhttp = new XMLHttpRequest();

    /* El uso de async = false está desaprobado y será eliminado en un futuro.
    Para simplificar la práctica NO se ha añadido el código javascript a un
    web worker como se aconseja, NI utilizado javascript asincrono, ya que
    requería la reestructuración de gran parte del código */
    xhttp.open("GET", filename, false);
    // Helping IE11
    try {xhttp.responseType = "sxml-document"} catch(exception) {}
    xhttp.send();    

    return xhttp.responseXML;
}

// Esta función carga la información del header y footer, así como el contenido de la página principal.
function cargaPrincipal() {

    // Localizar los elementos del DOM donde insertaremos el código generado.
    var header = document.getElementsByTagName("nav")[0];
    var content = document.getElementById("content");
    var footer = document.getElementsByTagName("footer")[0];

    // Construir la ruta de los archivos necesarios (mejora la portabilidad y rehusabilidad del código).
    var xsl_header = loadXMLDoc(xslPath + "header.xsl");
    var xsl_content = loadXMLDoc(xslPath + "ciclos.xsl");
    var xsl_footer = loadXMLDoc(xslPath + "footer.xsl");
    
    // Si el navegador usado es IE11, se muestra un mensaje de error y no se carga el contenido.
    if(window.ActiveXObject || xhttp.responseType === "msxml-document") {  
        alert("¡Usa un navegador de este siglo!\n\nInternet Explorer tiene problemas de incompatibilidad con el contenido de esta web. Por favor, actualiza a un navegador más moderno para una mejor experiencia de uso.");
    }
    // Para el resto de navegadores...
    else if(document.implementation && document.implementation.createDocument) {
        
        // Crear un procesador de XSLT para cada archivo .xsl (mejora la comprensión del código a costa de mayor espacio en memoria).
        var xsltProcessor_header = new XSLTProcessor();
        xsltProcessor_header.importStylesheet(xsl_header);
        var xsltProcessor_content = new XSLTProcessor();
        xsltProcessor_content.importStylesheet(xsl_content);
        var xsltProcessor_footer = new XSLTProcessor();
        xsltProcessor_footer.importStylesheet(xsl_footer);
      
        // Genera los códigos HTMl a partir del XML general y los respectivos XSL.
        var resultFragment_header = xsltProcessor_header.transformToFragment(xml, document);
        var resultFragment_content = xsltProcessor_content.transformToFragment(xml, document);
        var resultFragment_footer = xsltProcessor_footer.transformToFragment(xml, document);

        // Añade los códigos generados al final de cada elemento.
        header.appendChild(resultFragment_header);
        content.appendChild(resultFragment_content);
        footer.appendChild(resultFragment_footer);
    }
}

// Esta función mostrará la información de los módulos del ciclo seleccionado.
function cargaModulos(boton) {

    var id = boton.name;

    // Cambiar el elemento activo del menú (apagar el anterior y encender el nuevo).
    document.getElementsByClassName("active")[0].classList.remove("active");
    document.getElementsByName(id)[0].classList.add("active");

    // Localizar el elemento del DOM donde insertaremos el código generado.
    var content = document.getElementById("content");

    // Construir la ruta de los archivos necesarios (mejora la portabilidad y rehusabilidad del código).
    var xsl = loadXMLDoc(xslPath + "modulos.xsl");

    // Si el navegador usado es IE11, se muestra un mensaje de error y no se carga el contenido.
    if(window.ActiveXObject || xhttp.responseType === "msxml-document") {  
        alert("¡Usa un navegador de este siglo!\n\nInternet Explorer tiene problemas de incompatibilidad con el contenido de esta web. Por favor, actualiza a un navegador más moderno para una mejor experiencia de uso.");
    } 
    // Para el resto de navegadores...
    else if(document.implementation && document.implementation.createDocument) {
        
        // Crear un procesador de XSLT.
        var xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xsl);

        // Añadir el parámetro que usaremos en el XSL para seleccionar la información del ciclo deseado.
        xsltProcessor.setParameter(null,"id",id);
      
        // Generar el código HTML a partir del XML y el XSL.
        var resultFragment = xsltProcessor.transformToFragment(xml, document);

        // Limpiar el contenido actual del elemento donde vamos a insertar el el nuevo.
        content.innerHTML = "";

        // Insertar el contenido generado nuevo.
        content.appendChild(resultFragment);
    }
}

// Inicialización del XML general.
xml = loadXMLDoc(xml);